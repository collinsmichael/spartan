RawWrite for Windows
====================
95, 98, ME, NT, 2K, XP

Under 95, 98 & ME you need diskio.dll.  It must be in the same directory as rawwritewin.exe